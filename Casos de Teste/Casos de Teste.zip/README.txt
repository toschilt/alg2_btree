Arquivo zip gerado em: 29/06/2021 12:03:14 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: TRABALHO 1 - BTREE